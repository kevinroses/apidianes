@extends('layouts.app')

@section('content')

    <taxes-index></taxes-index>
   
@endsection

